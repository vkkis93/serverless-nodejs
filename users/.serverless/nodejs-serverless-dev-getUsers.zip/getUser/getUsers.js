'use strict';

module.exports.main = (event, context, callback) =>  {

};
