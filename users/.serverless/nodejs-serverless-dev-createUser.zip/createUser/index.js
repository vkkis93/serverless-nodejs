'use strict';

const mongo = require('../lib')
module.exports.main = (event, context, callback) =>  {
     console.log(process.env);
};
